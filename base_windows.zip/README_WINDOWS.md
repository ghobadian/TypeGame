# Final Project

## Compile

To compile, use this command

```bash
gcc main_windows.c -o project
```

## Run

To Run, use this command

```bash
project.exe
```
