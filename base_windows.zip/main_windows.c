#include <stdio.h>
#include <windows.h>
#include <conio.h>

#include "helper_windows.h"

void my_callback_on_key_arrival(char c)
{
  // Just for test, remove this line
  printf("char arrived : %d\n", c);
  // Do something with this c
}

int main()
{
  // Menu stuff goes here
  HANDLE thread_id = start_listening(my_callback_on_key_arrival);
  // The rest of your main code goes here

  WaitForSingleObject(thread_id, INFINITE);
  return 0;
}
