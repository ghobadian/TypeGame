#include <printf.h>
#include <pthread.h>

#include "helper_unix.h"

void my_callback_on_key_arrival(char c)
{
  // Just for test, remove this line
  printf("char arrived : %d\n", c);
  // Do something with this c
}

int main()
{
  // Menu stuff goes here
  pthread_t thread_id = start_listening(my_callback_on_key_arrival);
  // The rest of your main code goes here


  pthread_join(thread_id, NULL);
  return 0;
}
